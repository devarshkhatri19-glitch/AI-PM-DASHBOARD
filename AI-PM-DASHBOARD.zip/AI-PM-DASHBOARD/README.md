# AI-PM-DASHBOARD

**Project Author:** Devarsh Khatri (static demo)  
**Repository:** AI-PM-DASHBOARD

---

## Overview (presented as my work)

I built **AI‑PM‑DASHBOARD**, a lightweight, static, single‑page application that demonstrates a modern project- and workforce-management dashboard with ticketing, real‑time simulation, and AI-driven insights & roadmap generation. The whole app is client-side so it can be hosted directly on **GitHub Pages** without any server or additional configuration.

Key features:
- Task management with progress tracking
- Ticketing system (open/close, priorities)
- Workforce management (add/activate/deactivate members)
- Simulated real‑time updates for progress and tickets
- Mock AI insights (heuristic-based) and automatic roadmap generation
- Timeline / activity feed for audit and presentation

> Note: AI features are implemented with simple heuristics and mock generation so the demo runs without API keys. It is structured so you can wire real AI (OpenAI / other) into the UI later.

---

## Tech stack & design decisions (how I built it)

- **Plain HTML + CSS + JavaScript** (no build step). Chosen for maximum portability and to run directly from GitHub Pages.
- **LocalStorage** to persist data per user (no database required).
- **Client-side "AI"**: heuristic rules that analyze workload, ticket density and progress to provide insights. A "Generate Roadmap" button composes a sample roadmap from current tasks.
- **Real-time simulation**: `setInterval` drives mock updates to show how a real-time system would surface changes.
- **Single-file logic** in `app.js` for ease of editing and clarity.

This approach allows quick demos that are error-free when deployed to GitHub Pages.

---

## How to run (deploy on GitHub Pages)

1. Create a repository (or use the provided one). Upload these files to the repository root:
   - `index.html`
   - `styles.css`
   - `app.js`
   - `README.md`

2. In the GitHub repo, go to **Settings → Pages** and enable GitHub Pages from the `main` branch (root). The site will be available at:
   ```
   https://<username>.github.io/<repo>/
   ```

3. Open the URL. The dashboard will load and run in the browser — no server required.

---

## How AI is integrated (explain like you built it)

In this demo I integrated AI in two ways:

1. **Heuristic AI insights** — a lightweight rules engine (in `app.js`) that scans tasks, tickets and team size, and then proposes prioritized suggestions such as triage high‑priority tickets, reassign overloaded members and reduce work‑in‑progress.

2. **Roadmap generation** — the app builds a phased roadmap by synthesizing current tasks into Q1–Q4 buckets. The pattern is intentionally simple so it can be replaced with a call to an LLM (for example: "Use OpenAI GPT to rephrase and enrich the roadmap with business rationale").

If you want to upgrade to real OpenAI calls later:
- Add a backend or use GitHub Actions with secrets to keep API keys private.
- Replace the mock functions with `fetch` calls to your backend which calls OpenAI (or call a serverless function).

---

## How to present / explain this project (script you can use)

> "AI‑PM‑DASHBOARD is a lightweight demonstration I built to show how project managers can use realtime insights and AI-assisted recommendations to make faster decisions. The app tracks tasks and tickets, models team capacity, and provides AI-driven recommendations and a generated roadmap. It's intentionally static and client-side so it can be deployed instantly on GitHub Pages — but architected so you can swap the mock AI with a real LLM backend and add authentication and a production database."

Key talking points:
- Demo shows end-to-end flow: from creating tasks to viewing AI suggestions.
- Real‑time simulation illustrates how live updates would appear in production.
- Roadmap generation shows how AI can convert backlog items into prioritized releases.
- The app is fully portable and ideal as a portfolio piece or prototype.

---

## Files included
- `index.html` — UI and layout
- `styles.css` — styles
- `app.js` — application logic, persistence, AI heuristics
- `README.md` — this file

---

## License
MIT — feel free to modify, extend, and present as your prototype.

---

## Final notes
I created this demo as a portable, no‑friction way to showcase project management, workforce insights, ticketing and AI-assisted roadmap thinking. It is intentionally written as a static app so it "just works" on GitHub Pages and can be presented live during interviews or demos.
