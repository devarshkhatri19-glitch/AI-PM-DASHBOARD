// AI-PM-DASHBOARD — Single-file client-side logic
(function(){
  // Simple in-memory DB (persisted to localStorage)
  const DB_KEY = "ai_pm_dashboard_v1";
  const defaultState = {
    tasks: [
      { id: id(), title: "Onboard client A", owner: "Priya", progress: 20, status: "in-progress", updated: Date.now() - 1000*60*60*24 },
      { id: id(), title: "Design landing page", owner: "Alex", progress: 60, status: "in-progress", updated: Date.now() - 1000*60*60*6 },
      { id: id(), title: "Setup CI pipeline", owner: "Ravi", progress: 0, status: "todo", updated: Date.now() - 1000*60*60*48 }
    ],
    tickets: [
      { id: id(), title: "Bug: login redirect", priority: "High", status: "open", created: Date.now() - 1000*60*60*5 },
      { id: id(), title: "UI: button spacing", priority: "Low", status: "open", created: Date.now() - 1000*60*60*24 }
    ],
    workforce: [
      { id: id(), name: "Priya", role: "PM", active: true },
      { id: id(), name: "Alex", role: "Designer", active: true },
      { id: id(), name: "Ravi", role: "Developer", active: true }
    ],
    events: []
  };

  function id(){ return Math.random().toString(36).slice(2,9); }

  function load(){ try{ return JSON.parse(localStorage.getItem(DB_KEY)) || defaultState } catch(e){ return defaultState } }
  function save(s){ localStorage.setItem(DB_KEY, JSON.stringify(s)) }

  let state = load();

  // DOM refs
  const tasksEl = document.getElementById("tasks");
  const ticketsEl = document.getElementById("tickets");
  const workforceEl = document.getElementById("workforce");
  const cardOpenTasks = document.getElementById("card-open-tasks");
  const cardOpenTickets = document.getElementById("card-open-tickets");
  const cardActiveWorkforce = document.getElementById("card-active-workforce");
  const cardProgress = document.getElementById("card-progress");
  const timelineEl = document.getElementById("timeline");
  const aiInsightsEl = document.getElementById("ai-insights");
  const roadmapEl = document.getElementById("roadmap");
  const simulateCheckbox = document.getElementById("simulate-real-time");

  // Initial populate
  function render(){
    // tasks
    tasksEl.innerHTML = "";
    state.tasks.forEach(t=>{
      const li = document.createElement("li"); li.className="item";
      li.innerHTML = `<div>
        <strong>${escape(t.title)}</strong>
        <div class="meta">${escape(t.owner)} • ${t.status} • ${t.progress}%</div>
      </div>
      <div>
        <button class="small" data-act="inc" data-id="${t.id}">+10%</button>
        <button class="small" data-act="toggle" data-id="${t.id}">${t.status==="done"?"Reopen":"Done"}</button>
      </div>`;
      tasksEl.appendChild(li);
    });

    // tickets
    ticketsEl.innerHTML = "";
    state.tickets.forEach(t=>{
      const li = document.createElement("li"); li.className="item";
      li.innerHTML = `<div>
        <strong>${escape(t.title)}</strong>
        <div class="meta">Priority: ${escape(t.priority)} • ${t.status}</div>
      </div>
      <div>
        <button class="small" data-act="close-ticket" data-id="${t.id}">Close</button>
      </div>`;
      ticketsEl.appendChild(li);
    });

    // workforce
    workforceEl.innerHTML = "";
    state.workforce.forEach(m=>{
      const li = document.createElement("li"); li.className="item";
      li.innerHTML = `<div><strong>${escape(m.name)}</strong><div class="meta">${m.role} • ${m.active?"Active":"Inactive"}</div></div>
      <div>
        <button class="small" data-act="toggle-member" data-id="${m.id}">${m.active?"Deactivate":"Activate"}</button>
      </div>`;
      workforceEl.appendChild(li);
    });

    // cards
    cardOpenTasks.textContent = state.tasks.filter(t=>t.status!=="done").length;
    cardOpenTickets.textContent = state.tickets.filter(t=>t.status==="open").length;
    cardActiveWorkforce.textContent = state.workforce.filter(m=>m.active).length;
    const avgProgress = Math.round((state.tasks.reduce((s,t)=>s+t.progress,0) / Math.max(1,state.tasks.length)) || 0);
    cardProgress.textContent = avgProgress + "%";
    // timeline
    timelineEl.innerHTML = "";
    state.events.slice(-12).reverse().forEach(ev=>{
      const d = new Date(ev.t);
      const div = document.createElement("div");
      div.className = "item";
      div.style.borderLeft = "4px solid #eef2ff";
      div.innerHTML = `<div><strong>${escape(ev.title)}</strong><div class="meta">${d.toLocaleString()}</div></div>`;
      timelineEl.appendChild(div);
    });
    // insights placeholder
    renderAIInsightPlaceholder();
    renderRoadmap();
  }

  function pushEvent(title){
    state.events.push({ id:id(), title, t: Date.now() });
    if(state.events.length>200) state.events.shift();
    save(state);
  }

  // helpers
  function escape(s){ return (s||"").toString().replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;") }

  // attach controls
  document.getElementById("add-task").addEventListener("click", ()=>{
    const title = document.getElementById("new-task-title").value.trim();
    const owner = document.getElementById("new-task-owner").value || "Unassigned";
    if(!title) return alert("Enter task title");
    const t = { id:id(), title, owner, progress:0, status:"todo", updated:Date.now() };
    state.tasks.push(t); save(state); pushEvent(`Task created: ${title}`); render();
    document.getElementById("new-task-title").value="";
  });

  document.getElementById("add-ticket").addEventListener("click", ()=>{
    const title = document.getElementById("new-ticket-title").value.trim();
    const priority = document.getElementById("new-ticket-priority").value;
    if(!title) return alert("Enter ticket title");
    const tk = { id:id(), title, priority, status:"open", created:Date.now() };
    state.tickets.push(tk); save(state); pushEvent(`Ticket opened: ${title}`); render();
    document.getElementById("new-ticket-title").value="";
  });

  document.getElementById("add-member").addEventListener("click", ()=>{
    const name = document.getElementById("new-member-name").value.trim();
    const role = document.getElementById("new-member-role").value;
    if(!name) return alert("Enter member name");
    const m = { id:id(), name, role, active:true };
    state.workforce.push(m); save(state); pushEvent(`Member added: ${name}`); render();
    document.getElementById("new-member-name").value="";
    populateOwnerSelect();
  });

  // task and ticket actions (event delegation)
  tasksEl.addEventListener("click", (ev)=>{
    const btn = ev.target.closest("button");
    if(!btn) return;
    const act = btn.dataset.act, tid = btn.dataset.id;
    const t = state.tasks.find(x=>x.id===tid);
    if(!t) return;
    if(act==="inc"){ t.progress = Math.min(100, t.progress + 10); if(t.progress===100) t.status="done"; t.updated=Date.now(); pushEvent(`Task progress: ${t.title} → ${t.progress}%`); save(state); render(); }
    if(act==="toggle"){ t.status = (t.status==="done")?"in-progress":"done"; t.updated=Date.now(); pushEvent(`Task status: ${t.title} → ${t.status}`); save(state); render(); }
  });

  ticketsEl.addEventListener("click", (ev)=>{
    const btn = ev.target.closest("button"); if(!btn) return;
    const act = btn.dataset.act, tid = btn.dataset.id;
    const t = state.tickets.find(x=>x.id===tid);
    if(!t) return;
    if(act==="close-ticket"){ t.status="closed"; pushEvent(`Ticket closed: ${t.title}`); save(state); render(); }
  });

  workforceEl.addEventListener("click", (ev)=>{
    const btn = ev.target.closest("button"); if(!btn) return;
    const act = btn.dataset.act, idm = btn.dataset.id;
    const m = state.workforce.find(x=>x.id===idm);
    if(!m) return;
    if(act==="toggle-member"){ m.active = !m.active; pushEvent(`${m.active? "Activated":"Deactivated"}: ${m.name}`); save(state); render(); populateOwnerSelect(); }
  });

  // populate owner select
  function populateOwnerSelect(){
    const sel = document.getElementById("new-task-owner");
    sel.innerHTML = "";
    state.workforce.forEach(m=>{ const o = document.createElement("option"); o.value=m.name; o.textContent = `${m.name} (${m.role})`; sel.appendChild(o); });
  }

  // AI insights (mock)
  function heuristicInsights(){
    // simple rules: overloaded owners, many high priority open tickets, low progress tasks
    const overloaded = {};
    state.tasks.forEach(t=>{ if(t.status!=="done"){ overloaded[t.owner] = (overloaded[t.owner]||0)+1 }});
    const overloadedList = Object.entries(overloaded).filter(([k,v])=>v>=3).map(([k,v])=>`${k} (${v} tasks)`);
    const highTickets = state.tickets.filter(t=>t.priority==="High" && t.status==="open").length;
    const avgProgress = Math.round((state.tasks.reduce((s,t)=>s+t.progress,0) / Math.max(1,state.tasks.length))||0);
    const suggestions = [];
    if(overloadedList.length) suggestions.push("Workload imbalance: " + overloadedList.join(", "));
    if(highTickets>0) suggestions.push(`There are ${highTickets} high priority open ticket(s) — consider triaging.`);
    if(avgProgress < 40) suggestions.push("Overall progress is low — recommend focusing on blockers and reducing WIP.");
    if(state.workforce.filter(m=>m.active).length < 2) suggestions.push("Team is small — consider shifting timelines or adding contractors.");
    if(suggestions.length===0) suggestions.push("System looks healthy. No immediate actions suggested.");
    return { suggestions, avgProgress, highTickets, overloadedList };
  }

  function renderAIInsightPlaceholder(){
    const out = heuristicInsights();
    aiInsightsEl.innerHTML = `<div><strong>Summary:</strong> Avg progress ${out.avgProgress}% • ${out.highTickets} high tickets</div>
    <ul>${out.suggestions.map(s=>`<li>${escape(s)}</li>`).join("")}</ul>
    <div style="margin-top:8px"><button id="btn-suggest-actions" class="small">Suggest Actions</button></div>`;
    document.getElementById("btn-suggest-actions").addEventListener("click", ()=>{ showSuggestedActions(out) });
  }

  function showSuggestedActions(info){
    const list = info.suggestions.map(s=>`<li>${escape(s)}</li>`).join("");
    aiInsightsEl.innerHTML = `<h4>Recommended Actions</h4><ul>${list}</ul>
      <div><button id="btn-generate-checklist" class="small">Generate Quick Checklist</button></div>`;
    document.getElementById("btn-generate-checklist").addEventListener("click", ()=>{
      const checklist = [
        "Triage high priority tickets within 24 hours",
        "Reassign tasks from overloaded members",
        "Run daily 15-min blocker meeting",
        "Reduce WIP: pause low-impact tasks"
      ];
      aiInsightsEl.innerHTML = `<h4>Quick Checklist</h4><ol>${checklist.map(x=>`<li>${escape(x)}</li>`).join("")}</ol>`;
    });
  }

  // Roadmap generator (mock AI) — produce phased roadmap from current state
  function generateRoadmap(){
    const features = state.tasks.slice(0,6).map(t=>t.title);
    const roadmap = [
      { phase: "Q1 (Immediate)", items: features.slice(0,2) },
      { phase: "Q2 (Near-term)", items: features.slice(2,4) },
      { phase: "Q3 (Mid-term)", items: features.slice(4,6) },
      { phase: "Q4 (Long-term)", items: ["Scalability improvements", "UX refresh", "AI ops"] }
    ];
    return roadmap;
  }

  function renderRoadmap(){
    const rm = generateRoadmap();
    roadmapEl.innerHTML = rm.map(r=>`<div style="margin-bottom:8px"><strong>${r.phase}</strong><ul>${r.items.map(i=>`<li>${escape(i)}</li>`).join("")}</ul></div>`).join("");
  }

  // buttons: AI Insight
  document.getElementById("btn-ai-insight").addEventListener("click", ()=>{
    const info = heuristicInsights();
    alert("AI Insight (mock):\n- Avg progress: " + info.avgProgress + "%\n- Suggestions: " + info.suggestions.slice(0,3).join(" | "));
  });
  document.getElementById("btn-generate-roadmap").addEventListener("click", ()=>{
    const rm = generateRoadmap();
    roadmapEl.innerHTML = `<h4>Generated Roadmap</h4>` + rm.map(r=>`<div style="margin-bottom:8px"><strong>${r.phase}</strong><ul>${r.items.map(i=>`<li>${escape(i)}</li>`).join("")}</ul></div>`).join("");
    pushEvent("AI generated roadmap");
    save(state); render();
  });

  // Simulated real-time updates
  function realtimeTick(){
    if(!simulateCheckbox.checked) return;
    // randomly pick a task and increment progress
    if(Math.random() < 0.6 && state.tasks.length){
      const t = state.tasks[Math.floor(Math.random()*state.tasks.length)];
      if(t.status!=="done"){
        const inc = Math.floor(Math.random()*15);
        t.progress = Math.min(100, t.progress + inc);
        if(t.progress===100) t.status="done";
        t.updated = Date.now();
        pushEvent(`Auto-update: ${t.title} → ${t.progress}%`);
      }
    }
    // random ticket creation occasionally
    if(Math.random() < 0.08){
      const tk = { id:id(), title: "Auto ticket "+Math.random().toString(36).slice(2,6), priority: ["Low","Medium","High"][Math.floor(Math.random()*3)], status:"open", created:Date.now() };
      state.tickets.push(tk);
      pushEvent("Auto ticket created: " + tk.title);
    }
    save(state); render();
  }

  setInterval(realtimeTick, 5000);

  // initial render
  populateOwnerSelect();
  render();

  // expose for debugging in console
  window.__AI_PM_DB = state;

  // small helper: load sample demo reset
  window.resetDemo = function(){
    if(confirm("Reset demo data?")){ localStorage.removeItem(DB_KEY); location.reload(); }
  };
})();
